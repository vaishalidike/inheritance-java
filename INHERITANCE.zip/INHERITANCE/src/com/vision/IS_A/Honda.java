package com.vision.IS_A;

public class Honda extends Bike{
	//BIKE IS-A parent of honda
	// object IS-A parent of all java classess

}
