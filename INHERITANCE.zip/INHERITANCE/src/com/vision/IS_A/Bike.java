package com.vision.IS_A;

public class Bike {
	public void m1() {

}
}