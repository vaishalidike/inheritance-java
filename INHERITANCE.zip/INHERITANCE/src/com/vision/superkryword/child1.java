package com.vision.superkryword;

public class child1 extends parent1 {
	public void m1() {
	System.out.println("child1 method");
}


   public void m2() {
	  super.m1();
	  this.m1();
	
   }
	

    public static void main(String[] args) {
	child1 c1 = new child1 ();
	c1.m2();
	
	
    }
    }
	
	


	
	 
	
	




