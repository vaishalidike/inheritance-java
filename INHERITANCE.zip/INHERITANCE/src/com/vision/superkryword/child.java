package com.vision.superkryword;

public class child extends parent{
	int i=30;
	public void m1() {
		
		System.out.println("value of i:"+super.i);
	}
	public static void main(String[] args) {
		child c1=new child();
		c1.m1();
		
		
		
		
		
	}

}
