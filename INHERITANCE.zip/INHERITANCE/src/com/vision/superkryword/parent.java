package com.vision.superkryword;

public class parent {
	int i=20;

}
