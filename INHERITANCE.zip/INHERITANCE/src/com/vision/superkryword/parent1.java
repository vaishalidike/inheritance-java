package com.vision.superkryword;

public class parent1 {
	public void m1() {
		System.out.println("parent1 method");
	}

}
