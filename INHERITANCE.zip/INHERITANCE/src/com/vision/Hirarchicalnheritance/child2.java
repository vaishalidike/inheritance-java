package com.vision.Hirarchicalnheritance;

public class child2 {
	public void child2Method() {
		System.out.println("child2 method called");
	}
	public static void main(String[] args) {
	//parent object
	parent p1 = new parent();
	p1.parentMethod();
	//child2 object 
	child2 c2 = new child2();
	//c2.parentMethod();
	c2.child2Method();
	//creating of object of child2 using reference of parent
	parent p2 = new child1();
	p2.parentMethod();
	}
	
		
	}
	
 

