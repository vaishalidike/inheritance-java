package com.vision.Hirarchicalnheritance;

public class child1 extends parent{
	public void child1Method() {
	System.out.println("child1 method called");
}
//when we are creating object with parent reference we can call only the 
// methods of parent class 
public static void main(String[] args) {
// parent object
parent p1 = new parent();
p1.parentMethod();
//child1 object
child1 c1 = new child1();

c1.parentMethod();
c1.child1Method();
//creating object of child1 using reference of parent
parent p2 = new child1();
p2.parentMethod();
}
}