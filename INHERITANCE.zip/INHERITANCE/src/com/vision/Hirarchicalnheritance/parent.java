package com.vision.Hirarchicalnheritance;

public class parent {
	public void parentMethod() {
		System.out.println("parent methd called");
		
	}

}
