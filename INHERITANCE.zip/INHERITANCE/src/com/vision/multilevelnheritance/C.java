package com.vision.multilevelnheritance;

public class C extends B{
	public void methodC() {
		System.out.println("class C method");
	}
	
	public static void main(String[] args) {
		// created object of class A
		A a1 = new A();
		a1.methodA();
		// created object of class B
		B b1 = new B();
		b1.methodA();
		b1.methodB();
		//created object of classC
		C c1 = new C ();
		c1.methodA();
		c1.methodB();
		c1.methodC();
		//object of b using reference of A
		A a2 = new B();
		a2.methodA();
		// object of c using references of A
		A a3 = new C();
		a3.methodA();
		// object of C using reference of B
		B b2 = new C();
		b2.methodA();
		b2.methodB();
		
	}

}
