package com.vision.multilevelnheritance;

public class B extends A{
	public void methodB() {
	System.out.println("class B method");
}
	
}

