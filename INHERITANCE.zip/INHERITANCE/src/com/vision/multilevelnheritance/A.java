package com.vision.multilevelnheritance;
public class A {
	public void methodA() {
		System.out.println("class A method");
	}
	
	}
