package com.vision.constructor;

public class parent {
	public parent(){
		super();
		System.out.println("paret class constructor");
	}
}
		
			
