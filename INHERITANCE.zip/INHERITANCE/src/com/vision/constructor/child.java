package com.vision.constructor;

public class child extends  parent{
    
   public child() {
	   super();
	   // purpose of super is to call super class const
	   System.out.println("child class constructor");
}

 public static void main(String[] args) {
	//child c1 = new child();
	//parent p1=new parent();
	parent p2 = new child();
	   
}
}
 