package com.visionmultipleinheritance;

public class Child extends parent1, parent2{

}
