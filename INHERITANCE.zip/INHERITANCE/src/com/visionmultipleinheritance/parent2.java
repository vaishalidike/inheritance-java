package com.visionmultipleinheritance;

public class parent2 {

}
