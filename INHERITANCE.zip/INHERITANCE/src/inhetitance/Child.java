package inhetitance;

public class Child extends parent  {
	public void m2() {
		System.out.println("child method called");
	}
	
	public static void main(String[] args) {
		// creating parent object by using parent references and parent object 
		parent p1 = new parent ();
		p1.m1();
		//p1.m2();
		//creating object of child using child references and child object
		Child c1 = new Child();
		c1.m1();
		c1.m2();
		//creating object by parent  references and child object 
		parent p2 = new Child ();
		p2.m1 ();
		// p2.m2();
		
		
		
	}

}
