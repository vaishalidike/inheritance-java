
package inhetitance;

public class UnicornBike {
	public void increasedSpeed() {
		System.out.println("Speed is increased");
	}
	
	public void decreasedSpeed () {
		System.out.println("Speed is decreased");
	}
	public static void main (String[] args) {
		UnicornBike u=new UnicornBike ();
	//	u.decreasedSpeed ();
	//	u.increasedSpeed ();
		
	}
	
	
}
	
	
    	  
      