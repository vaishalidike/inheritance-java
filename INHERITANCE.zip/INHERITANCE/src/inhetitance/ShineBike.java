package inhetitance;

// inheritance is acquiring properies and behaviour of one 
// class into another class 
// by using extend keyword we can achive inheritance between two classes
// benifits of inheritance is coad resability.
// single inheritance
public class ShineBike extends UnicornBike {
	// class mentioned to right side of extend keyword is called as
	// super class(parent class)
	// sub class (child class )
	
	// public void increasedSpeed (){
	// System.out.println("speed is increased");
	//}
	//
	// public void decreasedSpeed (){
	// System.out.println("Speed is decreased");
	//}
	public static void main (String[] args) {
		//child class references and child class object (ShineBike)
		ShineBike s1 = new ShineBike ();
	//	s1.increasedSpeed();
		s1.decreasedSpeed();
		// parent class referance and parent class object(UnicornBike)
		UnicornBike u1 =  new UnicornBike ();
		u1.increasedSpeed();
		u1.decreasedSpeed();
		// creating aan object of child class by usingparent class referances
		UnicornBike b1  =new ShineBike();
		b1.increasedSpeed();
	//	b2.decreasedSpeed();
		//we cant createobject of parent class using child referances
		// parent class=UnicornBike
		// child class=ShineBike
		//ShineBike a1 = new UnicornBike();
	}


		
		
		
	

}
