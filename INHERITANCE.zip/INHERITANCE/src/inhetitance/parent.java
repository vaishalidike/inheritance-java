package inhetitance;

public class parent {
	public void m1 () {
		System.out.println("parent method calls");
	}

}
